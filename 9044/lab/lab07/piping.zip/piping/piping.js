function buildPipe() {

}

// This is how we can export functions in node
// in the same way we can use the "export" keyword in browser 
// side JS
module.exports = buildPipe;