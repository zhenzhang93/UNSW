(function() {
  'use strict';
  // TODO: Write some js
}());
