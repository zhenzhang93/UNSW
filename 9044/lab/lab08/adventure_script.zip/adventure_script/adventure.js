(function() {
   'use strict';
   // code here
}());
