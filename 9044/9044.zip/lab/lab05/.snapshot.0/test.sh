#!/bin/sh


a=`seq 40 50|sort -r| head -n1`
echo $a
