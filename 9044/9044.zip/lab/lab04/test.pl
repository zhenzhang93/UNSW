#!/usr/bin/perl -w

$num = 2;

print int(rand($num)),"\n";
