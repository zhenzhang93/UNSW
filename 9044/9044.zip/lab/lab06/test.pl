#!/usr/bin/perl -w



$content = $ARGV[0];
$a= " print \\\" print \"print $content\"\; \\\"\\\; \"";

print "$a\n";
