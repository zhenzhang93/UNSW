const one = process.argv[2]; // will be "one"
string = "Hello " + one;
console.log(string);
