#/usr/bin/perl -w

$a = "fsafdsf";

$b = length($a);
print "$b\n";
