(function() {
   'use strict';
   // write your code here

}());
